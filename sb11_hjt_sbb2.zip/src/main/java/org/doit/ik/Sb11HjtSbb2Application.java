package org.doit.ik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb11HjtSbb2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb11HjtSbb2Application.class, args);
	}

}
