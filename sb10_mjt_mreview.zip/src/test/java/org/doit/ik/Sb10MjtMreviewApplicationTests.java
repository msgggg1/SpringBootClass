package org.doit.ik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb10MjtMreviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
