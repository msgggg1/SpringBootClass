package org.doit.ik.mreview.repository;

import java.util.stream.IntStream;

import org.doit.ik.mreview.entity.Member;
import org.doit.ik.mreview.entity.Movie;
import org.doit.ik.mreview.entity.Review;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.log4j.Log4j2;

@SpringBootTest
@Log4j2
class ReviewRepositoryTests {

	@Autowired
	private ReviewRepository reviewRepository;


	@Test
	void insertMovieReviews() {
		IntStream.rangeClosed(1, 200).forEach(i->{
			log.info("👌 ReviewRepositoryTests.insertMovieReviews()...");
			Long mno = (long)(Math.random()*100)+1;   // 영화 번호
			Long mid = (long)(Math.random()*100)+1;   // 리뷰어 번호
			Member member = Member.builder()
					.mid(mid)
					.build();
			Review review = Review.builder()
					.member(member)
					.movie(Movie.builder().mno(mno).build())
					.grade((int)(Math.random()*5)+1)
					.text("이 영화에 대한 느낌..."+i)
					.build();

			this.reviewRepository.save(review);
		});
	}

}
