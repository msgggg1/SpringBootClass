package org.doit.ik.mreview.repository;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import java.util.stream.IntStream;

import org.doit.ik.mreview.entity.Member;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.log4j.Log4j2;

@SpringBootTest
@Log4j2
class MemberRepositoryTests {

	@Autowired
	private MemberRepository memberRepository;

	/*
	@Test
	   void insertMembers() {
	      IntStream.rangeClosed(1, 100).forEach(i->{
	         log.info("👌 MemberRepositoryTests.insertMembers()...");
	         Member member = Member.builder()
	               .email("r"+i+"@doit.com")
	               .pw("1111")
	               .nickname("reviewer"+i)
	               .build();
	         this.memberRepository.save(member);
	      });
	   }
	   */
}
