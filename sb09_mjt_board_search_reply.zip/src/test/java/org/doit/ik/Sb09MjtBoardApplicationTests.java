package org.doit.ik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb09MjtBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
